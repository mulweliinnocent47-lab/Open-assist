package com.openassist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.openassist.data.local.SecureStorage
import com.openassist.ui.chat.ChatScreen
import com.openassist.ui.onboarding.OnboardingScreen
import com.openassist.viewmodel.ChatViewModel
import com.openassist.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as OpenAssistApp

        // Re-register the launcher on every onCreate so PermissionManager always
        // has a live launcher, even after a configuration change.  Any in-flight
        // CompletableDeferred in PermissionManager is unaffected by this swap.
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions(),
        ) { results ->
            app.permissionManager.onResult(results)
        }
        app.permissionManager.attachLauncher(permissionLauncher)

        val storage = SecureStorage(this)

        setContent {
            MaterialTheme {
                val settings: SettingsViewModel =
                    viewModel(factory = settingsFactory(storage))
                val apiKey by settings.apiKey.collectAsState()

                if (apiKey.isBlank()) {
                    OnboardingScreen(onSaveApiKey = settings::saveApiKey)
                } else {
                    // toolEngine lives in OpenAssistApp so the same instance is
                    // returned across Activity recreations; the ViewModel factory
                    // only runs once per ViewModel lifetime.
                    val chat: ChatViewModel =
                        viewModel(factory = chatFactory(storage, app))
                    ChatScreen(chatViewModel = chat, settingsViewModel = settings)
                }
            }
        }
    }
}

private fun settingsFactory(storage: SecureStorage) =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            SettingsViewModel(storage) as T
    }

private fun chatFactory(storage: SecureStorage, app: OpenAssistApp) =
    object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ChatViewModel(storage, app.toolEngine) as T
    }
